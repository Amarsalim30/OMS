package com.zeynbakers.order_management_system.core.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.zeynbakers.order_management_system.accounting.ui.LedgerScreen
import com.zeynbakers.order_management_system.accounting.ui.LedgerViewModel
import com.zeynbakers.order_management_system.accounting.ui.PaymentApplySummary
import com.zeynbakers.order_management_system.accounting.ui.ManualPaymentScreen
import com.zeynbakers.order_management_system.accounting.ui.MpesaImportScreen
import com.zeynbakers.order_management_system.accounting.ui.PaymentIntakeViewModel
import com.zeynbakers.order_management_system.customer.ui.CustomerAccountsViewModel

enum class MoneyTab {
    Mpesa,
    Manual,
    Ledger
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoneyScreen(
    selectedTab: MoneyTab,
    onTabChange: (MoneyTab) -> Unit,
    paymentIntakeViewModel: PaymentIntakeViewModel,
    customerViewModel: CustomerAccountsViewModel,
    ledgerViewModel: LedgerViewModel,
    initialText: String?,
    manualCustomerId: Long?,
    manualOrderId: Long?,
    onManualContextConsumed: () -> Unit,
    onApplied: (PaymentApplySummary) -> Unit,
    onAppliedInPlace: () -> Unit,
    onOpenReceiptHistory: (Long) -> Unit
) {
    Scaffold(
        topBar = {
            Column(modifier = androidx.compose.ui.Modifier.statusBarsPadding()) {
                TabRow(selectedTabIndex = selectedTab.ordinal) {
                    Tab(
                        selected = selectedTab == MoneyTab.Mpesa,
                        onClick = { onTabChange(MoneyTab.Mpesa) },
                        text = { Text("M-PESA") }
                    )
                    Tab(
                        selected = selectedTab == MoneyTab.Manual,
                        onClick = { onTabChange(MoneyTab.Manual) },
                        text = { Text("Manual") }
                    )
                    Tab(
                        selected = selectedTab == MoneyTab.Ledger,
                        onClick = { onTabChange(MoneyTab.Ledger) },
                        text = { Text("Ledger") }
                    )
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            MoneyTab.Mpesa -> {
                MpesaImportScreen(
                    viewModel = paymentIntakeViewModel,
                    initialText = initialText,
                    onClose = {},
                    onApplied = onApplied,
                    onAppliedInPlace = onAppliedInPlace,
                    onOpenReceiptHistory = onOpenReceiptHistory,
                    showTopBar = false,
                    externalPadding = padding
                )
            }
            MoneyTab.Manual -> {
                ManualPaymentScreen(
                    customerViewModel = customerViewModel,
                    initialCustomerId = manualCustomerId,
                    initialOrderId = manualOrderId,
                    onContextConsumed = onManualContextConsumed,
                    showTopBar = false,
                    externalPadding = padding
                )
            }
            MoneyTab.Ledger -> {
                LedgerScreen(
                    viewModel = ledgerViewModel,
                    onBack = {},
                    showTopBar = false,
                    externalPadding = padding
                )
            }
        }
    }
}
