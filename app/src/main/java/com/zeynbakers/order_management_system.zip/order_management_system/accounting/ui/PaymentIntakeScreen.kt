@file:Suppress("DEPRECATION")

package com.zeynbakers.order_management_system.accounting.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.zeynbakers.order_management_system.accounting.data.PaymentReceiptStatus
import com.zeynbakers.order_management_system.core.util.formatDateTime
import com.zeynbakers.order_management_system.core.util.formatKes
import com.zeynbakers.order_management_system.core.util.formatOrderLabel
import java.math.BigDecimal
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentIntakeScreen(
    viewModel: PaymentIntakeViewModel,
    initialText: String?,
    onClose: () -> Unit,
    onApplied: (PaymentApplySummary) -> Unit,
    onAppliedInPlace: () -> Unit,
    onOpenReceiptHistory: (Long) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val rawText by viewModel.rawText.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    var filter by remember { mutableStateOf(IntakeFilter.All) }
    var receiptDetails by remember { mutableStateOf<ExistingReceiptDetails?>(null) }
    var showAdvanced by remember { mutableStateOf(false) }

    LaunchedEffect(initialText) {
        val text = initialText?.trim().orEmpty()
        if (text.isNotBlank()) {
            viewModel.setRawText(text)
        }
    }

    val selectedCount = transactions.count { it.selected && it.duplicateState == DuplicateState.NONE }
    val totalDetected = transactions.size
    val duplicateCount = transactions.count { it.duplicateState != DuplicateState.NONE }
    val needsMatchCount =
        transactions.count { it.duplicateState == DuplicateState.NONE && !it.canApply() }
    val readyCount =
        transactions.count { it.duplicateState == DuplicateState.NONE && it.canApply() }
    val selectedAmount =
        transactions
            .filter { it.selected && it.duplicateState == DuplicateState.NONE }
            .fold(BigDecimal.ZERO) { acc, item -> acc + item.amount }

    val pasteFromClipboard = {
        val clip = clipboardManager.getText()?.text?.trim().orEmpty()
        if (clip.isBlank()) {
            Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        } else if (rawText.isBlank()) {
            viewModel.setRawText(clip)
        } else {
            viewModel.appendRawText(clip)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Import payments") },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (showAdvanced) {
                ApplyBar(
                    selectedCount = selectedCount,
                    selectedAmount = selectedAmount,
                    onApply = {
                        scope.launch {
                            val summary = viewModel.applySelected()
                            val message =
                                buildString {
                                    append("Applied ${summary.applied} payments")
                                    if (summary.existingDuplicates > 0) {
                                        append(", ${summary.existingDuplicates} already recorded")
                                    }
                                    if (summary.intakeDuplicates > 0) {
                                        append(", ${summary.intakeDuplicates} duplicates in import")
                                    }
                                    if (summary.skippedNoCustomer > 0) {
                                        append(", ${summary.skippedNoCustomer} missing customer")
                                    }
                                }
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            onApplied(summary)
                        }
                    }
                )
            }
        }
    ) { padding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
        ) {
            Text(
                text = "Import M-PESA messages",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "Multiple messages are supported. Separate each message with a blank line.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = rawText,
                onValueChange = { viewModel.setRawText(it) },
                label = { Text("Received text") },
                placeholder = { Text("Paste one or more messages") },
                trailingIcon = {
                    if (rawText.isNotBlank()) {
                        IconButton(onClick = { viewModel.setRawText("") }) {
                            Icon(imageVector = Icons.Filled.Delete, contentDescription = "Clear input")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                minLines = 4
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = pasteFromClipboard,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Filled.ContentPaste, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Paste from clipboard")
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = { showAdvanced = !showAdvanced }) {
                    Text(if (showAdvanced) "Hide advanced" else "Advanced")
                }
            }
            if (showAdvanced) {
                IntakeSummaryCard(
                    totalDetected = totalDetected,
                    readyCount = readyCount,
                    needsMatchCount = needsMatchCount,
                    duplicateCount = duplicateCount,
                    selectedCount = selectedCount,
                    selectedAmount = selectedAmount,
                    onSelectMatched = { viewModel.setAllSelected(true) },
                    onClearSelection = { viewModel.setAllSelected(false) }
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IntakeFilter.values().forEach { entry ->
                        val count =
                            when (entry) {
                                IntakeFilter.All -> totalDetected
                                IntakeFilter.Selected -> selectedCount
                                IntakeFilter.NeedsMatch -> needsMatchCount
                                IntakeFilter.Duplicates -> duplicateCount
                            }
                        FilterChip(
                            selected = filter == entry,
                            onClick = { filter = entry },
                            label = { Text("${entry.label} ($count)") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            val visibleTransactions by remember(transactions, filter, showAdvanced) {
                derivedStateOf {
                    if (!showAdvanced) {
                        transactions
                    } else {
                        when (filter) {
                            IntakeFilter.All -> transactions
                            IntakeFilter.Selected -> transactions.filter { it.selected }
                            IntakeFilter.NeedsMatch ->
                                transactions.filter {
                                    it.duplicateState == DuplicateState.NONE && !it.canApply()
                                }
                            IntakeFilter.Duplicates ->
                                transactions.filter { it.duplicateState != DuplicateState.NONE }
                        }
                    }
                }
            }

            if (transactions.isEmpty()) {
                Text(
                    text = "No transactions detected yet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
            } else if (visibleTransactions.isEmpty()) {
                Text(
                    text = "No transactions for this filter.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(visibleTransactions, key = { it.key }) { item ->
                    if (showAdvanced) {
                        MpesaTransactionCard(
                            item = item,
                            onToggleSelected = { selected ->
                                viewModel.toggleSelected(item.key, selected)
                            },
                            onSelectOrder = { orderId ->
                                viewModel.selectOrder(item.key, orderId)
                            },
                            onSelectAllocationMode = { mode ->
                                viewModel.selectAllocationMode(item.key, mode)
                            },
                            onReallocateExisting = {
                                scope.launch {
                                    val result = viewModel.reallocateExistingReceipt(item.key)
                                    Toast.makeText(context, result.message, Toast.LENGTH_SHORT).show()
                                }
                            },
                            onViewExisting = {
                                scope.launch {
                                    val id = item.existingReceiptId ?: return@launch
                                    receiptDetails = viewModel.loadExistingReceiptDetails(id)
                                    if (receiptDetails == null) {
                                        Toast.makeText(context, "Receipt not found", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        )
                    } else {
                        MpesaTransactionRow(
                            item = item,
                            onApply = {
                                scope.launch {
                                    val result = viewModel.applySingle(item.key)
                                    Toast.makeText(context, result.message, Toast.LENGTH_SHORT).show()
                                    if (result.success) {
                                        onAppliedInPlace()
                                    }
                                }
                            },
                            onMove = {
                                val target = item.existingReceiptId
                                if (target != null) {
                                    onOpenReceiptHistory(target)
                                } else {
                                    Toast.makeText(context, "Receipt not found", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onSelectOrder = { orderId ->
                                viewModel.selectOrder(item.key, orderId)
                            },
                            onSelectAllocationMode = { mode ->
                                viewModel.selectAllocationMode(item.key, mode)
                            }
                        )
                    }
                }
            }
        }
    }

    receiptDetails?.let { detail ->
        AlertDialog(
            onDismissRequest = { receiptDetails = null },
            title = { Text("Receipt #${detail.receiptId}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "${formatKes(detail.amount)} - ${detail.method.name}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = formatDateTime(detail.receivedAt),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Status: ${detail.status.name}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!detail.voidReason.isNullOrBlank()) {
                        Text(
                            text = "Void reason: ${detail.voidReason}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (detail.allocations.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Allocations",
                            style = MaterialTheme.typography.labelLarge
                        )
                        detail.allocations.forEach { allocation ->
                            val label =
                                allocation.orderLabel
                                    ?: allocation.orderId?.let { "Order ID $it" }
                                    ?: "Customer credit"
                            val statusLabel = allocation.status.name
                            Text(
                                text = "$label - ${formatKes(allocation.amount)} - $statusLabel",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (!allocation.voidReason.isNullOrBlank()) {
                                Text(
                                    text = "Reason: ${allocation.voidReason}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { receiptDetails = null }) {
                    Text("Close")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MpesaTransactionCard(
    item: MpesaTransactionUi,
    onToggleSelected: (Boolean) -> Unit,
    onSelectOrder: (Long?) -> Unit,
    onSelectAllocationMode: (AllocationMode) -> Unit,
    onReallocateExisting: () -> Unit,
    onViewExisting: () -> Unit
) {
    val isDuplicate = item.duplicateState != DuplicateState.NONE
    val isExistingDuplicate = item.duplicateState == DuplicateState.EXISTING
    val canApply = item.selectedCustomerId != null || item.selectedOrderId != null
    var showOptions by remember(item.key) {
        mutableStateOf(!isDuplicate && !canApply && item.orderSuggestions.isNotEmpty())
    }
    val selectedOrder = item.orderSuggestions.firstOrNull { it.orderId == item.selectedOrderId }
    val topSuggestion = item.orderSuggestions.firstOrNull()
            val statusLabel =
                when {
                    isDuplicate ->
                        when (item.duplicateState) {
                            DuplicateState.EXISTING -> {
                                when (item.existingReceiptStatus) {
                                    PaymentReceiptStatus.VOIDED -> "Already recorded (voided)"
                                    PaymentReceiptStatus.UNAPPLIED -> "Already recorded (not used)"
                                    PaymentReceiptStatus.PARTIAL -> "Already recorded (part used)"
                                    PaymentReceiptStatus.APPLIED -> "Already recorded (used)"
                                    null -> "Already recorded"
                                }
                            }
                            DuplicateState.INTAKE -> "Duplicate"
                            DuplicateState.NONE -> ""
                        }
            !canApply -> "Needs match"
            item.selected -> "Selected"
            else -> "Ready"
        }
    val statusColors =
        when {
            isDuplicate -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
            !canApply -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
            item.selected -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
            else -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
        }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = item.selected,
                    onCheckedChange = { checked -> onToggleSelected(checked) },
                    enabled = !isDuplicate && canApply
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    val codeLabel = item.transactionCode?.let { "Code $it" } ?: "No code"
                    Text(
                        text = "${formatKes(item.amount)} - $codeLabel",
                        style = MaterialTheme.typography.titleSmall
                    )
                    val sender =
                        item.senderName?.takeIf { it.isNotBlank() } ?: item.senderPhone?.takeIf { it.isNotBlank() }
                    if (sender != null) {
                        Text(
                            text = "From $sender",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    item.receivedAt?.let {
                        Text(
                            text = formatDateTime(it),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (statusLabel.isNotBlank()) {
                    Surface(
                        color = statusColors.first,
                        contentColor = statusColors.second,
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            val summaryLabel =
                when {
                    selectedOrder != null ->
                        "Selected: ${suggestionLabel(selectedOrder, 20)} - balance ${formatKes(selectedOrder.outstanding)}"
                    item.allocationMode == AllocationMode.OLDEST_ORDERS && item.selectedCustomerId != null ->
                        topSuggestion?.let {
                            "Oldest: ${suggestionLabel(it, 20)} - balance ${formatKes(it.outstanding)}"
                        } ?: item.suggestedCustomerName?.let { "Apply to oldest unpaid orders for $it" }
                            ?: "Apply to oldest unpaid orders"
                    item.allocationMode == AllocationMode.CUSTOMER_CREDIT && item.selectedCustomerId != null ->
                        item.suggestedCustomerName?.let { "Customer credit for $it" } ?: "Customer credit"
                    item.suggestedCustomerName != null ->
                        "Suggested customer: ${item.suggestedCustomerName} (${item.customerConfidence}%)"
                    topSuggestion != null ->
                        "Suggested: ${suggestionLabel(topSuggestion, 20)} - balance ${formatKes(topSuggestion.outstanding)}"
                    else -> "No match yet"
                }
            Text(
                text = summaryLabel,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!canApply && !isDuplicate) {
                Text(
                    text = "Needs customer match before applying.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
            if (!canApply && isExistingDuplicate) {
                Text(
                    text = "Select a customer or order to move the payment.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if ((item.orderSuggestions.isNotEmpty() || item.suggestedCustomerId != null) &&
                item.duplicateState != DuplicateState.INTAKE
            ) {
                Spacer(modifier = Modifier.height(6.dp))
                TextButton(onClick = { showOptions = !showOptions }) {
                    Text(if (showOptions) "Hide details" else "Why this match?")
                }
            }

            if (showOptions) {
                if (item.orderSuggestions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pick order",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OrderSuggestionChips(
                        item = item,
                        onSelectOrder = onSelectOrder
                    )
                }

                if (item.suggestedCustomerId != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = item.allocationMode == AllocationMode.CUSTOMER_CREDIT,
                            onClick = { onSelectAllocationMode(AllocationMode.CUSTOMER_CREDIT) },
                            label = { Text("Customer credit") }
                        )
                        FilterChip(
                            selected = item.allocationMode == AllocationMode.OLDEST_ORDERS,
                            onClick = { onSelectAllocationMode(AllocationMode.OLDEST_ORDERS) },
                            label = { Text("Oldest orders") }
                        )
                    }
                }
            }

            if (isExistingDuplicate) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onViewExisting) {
                        Text("Details")
                    }
                    val actionLabel = "Move"
                    Button(onClick = onReallocateExisting, enabled = canApply) {
                        Text(actionLabel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MpesaTransactionRow(
    item: MpesaTransactionUi,
    onApply: () -> Unit,
    onMove: () -> Unit,
    onSelectOrder: (Long?) -> Unit,
    onSelectAllocationMode: (AllocationMode) -> Unit
) {
    val isExistingDuplicate = item.duplicateState == DuplicateState.EXISTING
    val isIntakeDuplicate = item.duplicateState == DuplicateState.INTAKE
    val canApply = item.selectedCustomerId != null || item.selectedOrderId != null
    var showOptions by remember(item.key) {
        mutableStateOf(!isExistingDuplicate && !isIntakeDuplicate && !canApply)
    }

    val selectedOrder = item.orderSuggestions.firstOrNull { it.orderId == item.selectedOrderId }
    val codeLabel = item.transactionCode?.let { "M-PESA $it" } ?: "M-PESA"
    val timeLabel = item.receivedAt?.let { formatDateTime(it) }
    val lineOne = listOfNotNull(formatKes(item.amount), codeLabel, timeLabel).joinToString(" - ")
    val summaryLabel =
        when {
            isExistingDuplicate -> "Already recorded"
            isIntakeDuplicate -> "Duplicate in import"
            selectedOrder != null ->
                "Selected: ${suggestionLabel(selectedOrder, 18)} - ${formatKes(selectedOrder.outstanding)} due"
            item.allocationMode == AllocationMode.OLDEST_ORDERS && item.selectedCustomerId != null ->
                item.orderSuggestions.firstOrNull()?.let { suggestion ->
                    "Oldest: ${suggestionLabel(suggestion, 18)} - ${formatKes(suggestion.outstanding)} due"
                } ?: item.suggestedCustomerName?.let { "Oldest unpaid orders for $it" } ?: "Oldest unpaid orders"
            item.allocationMode == AllocationMode.CUSTOMER_CREDIT && item.selectedCustomerId != null ->
                item.suggestedCustomerName?.let { "Customer credit - $it" } ?: "Customer credit"
            item.suggestedCustomerName != null ->
                "Suggested customer: ${item.suggestedCustomerName}"
            else -> "Select a customer or order"
        }

    val actionLabel =
        when {
            isExistingDuplicate -> "Move"
            isIntakeDuplicate -> "Duplicate"
            canApply -> "Apply"
            else -> "Select target"
        }
    val actionEnabled =
        when {
            isIntakeDuplicate -> false
            isExistingDuplicate -> true
            actionLabel == "Select target" -> true
            else -> canApply
        }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = lineOne, style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = summaryLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Button(
                    onClick = {
                        when {
                            isExistingDuplicate -> onMove()
                            actionLabel == "Select target" -> showOptions = true
                            canApply -> onApply()
                            else -> showOptions = true
                        }
                    },
                    enabled = actionEnabled
                ) {
                    Text(actionLabel)
                }
            }

            if (!isExistingDuplicate &&
                !isIntakeDuplicate &&
                (item.orderSuggestions.isNotEmpty() || item.suggestedCustomerId != null)
            ) {
                Spacer(modifier = Modifier.height(6.dp))
                TextButton(onClick = { showOptions = !showOptions }) {
                    Text(if (showOptions) "Hide details" else "Why this match?")
                }
            }

            if (showOptions && !isExistingDuplicate && !isIntakeDuplicate) {
                val hasOptions =
                    item.orderSuggestions.isNotEmpty() || item.suggestedCustomerId != null
                if (item.orderSuggestions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pick order",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OrderSuggestionChips(
                        item = item,
                        onSelectOrder = onSelectOrder
                    )
                }

                if (item.suggestedCustomerId != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = item.allocationMode == AllocationMode.CUSTOMER_CREDIT,
                            onClick = { onSelectAllocationMode(AllocationMode.CUSTOMER_CREDIT) },
                            label = { Text("Customer credit") }
                        )
                        FilterChip(
                            selected = item.allocationMode == AllocationMode.OLDEST_ORDERS,
                            onClick = { onSelectAllocationMode(AllocationMode.OLDEST_ORDERS) },
                            label = { Text("Oldest orders") }
                        )
                    }
                }
                if (!hasOptions) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "No suggestions found for this payment.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OrderSuggestionChips(
    item: MpesaTransactionUi,
    onSelectOrder: (Long?) -> Unit
) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item.orderSuggestions.forEach { suggestion ->
            val label = "${suggestionLabel(suggestion, 14)} (${suggestion.confidence}%)"
            FilterChip(
                selected = item.selectedOrderId == suggestion.orderId,
                onClick = { onSelectOrder(suggestion.orderId) },
                label = { Text(label) }
            )
        }
    }
}

private enum class IntakeFilter(val label: String) {
    All("All"),
    Selected("Selected"),
    NeedsMatch("Needs match"),
    Duplicates("Duplicates")
}

private fun MpesaTransactionUi.canApply(): Boolean {
    return selectedCustomerId != null || selectedOrderId != null
}

private fun suggestionLabel(suggestion: MpesaOrderSuggestion, maxNotes: Int): String {
    return formatOrderLabel(
        date = suggestion.orderDate,
        customerName = suggestion.customerName,
        notes = suggestion.notes,
        totalAmount = null,
        maxNotes = maxNotes
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun IntakeSummaryCard(
    totalDetected: Int,
    readyCount: Int,
    needsMatchCount: Int,
    duplicateCount: Int,
    selectedCount: Int,
    selectedAmount: BigDecimal,
    onSelectMatched: () -> Unit,
    onClearSelection: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = "Summary", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryPill(
                    label = "Detected",
                    value = totalDetected,
                    container = MaterialTheme.colorScheme.surfaceVariant,
                    content = MaterialTheme.colorScheme.onSurfaceVariant
                )
                SummaryPill(
                    label = "Ready",
                    value = readyCount,
                    container = MaterialTheme.colorScheme.secondaryContainer,
                    content = MaterialTheme.colorScheme.onSecondaryContainer
                )
                SummaryPill(
                    label = "Needs match",
                    value = needsMatchCount,
                    container = MaterialTheme.colorScheme.tertiaryContainer,
                    content = MaterialTheme.colorScheme.onTertiaryContainer
                )
                SummaryPill(
                    label = "Duplicates",
                    value = duplicateCount,
                    container = MaterialTheme.colorScheme.errorContainer,
                    content = MaterialTheme.colorScheme.onErrorContainer
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Selected $selectedCount - Total ${formatKes(selectedAmount)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row {
                    TextButton(onClick = onSelectMatched) { Text("Select matched") }
                    TextButton(onClick = onClearSelection) { Text("Clear") }
                }
            }
        }
    }
}

@Composable
private fun SummaryPill(
    label: String,
    value: Int,
    container: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color
) {
    Surface(
        color = container,
        contentColor = content,
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = "$label $value",
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun ApplyBar(
    selectedCount: Int,
    selectedAmount: BigDecimal,
    onApply: () -> Unit
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Selected total",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = formatKes(selectedAmount),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Button(
                onClick = onApply,
                enabled = selectedCount > 0
            ) {
                val label = if (selectedCount == 0) "Apply" else "Apply $selectedCount"
                Text(label)
            }
        }
    }
}
