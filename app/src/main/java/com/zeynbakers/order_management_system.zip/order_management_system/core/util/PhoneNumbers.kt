package com.zeynbakers.order_management_system.core.util

fun normalizePhoneNumber(raw: String): String {
    return raw.filter { it.isDigit() || it == '+' }
}

fun expandPhoneCandidates(raw: String): List<String> {
    val normalized = normalizePhoneNumber(raw)
    if (normalized.isBlank()) return emptyList()
    val digits = normalized.filter { it.isDigit() }
    if (digits.isBlank()) return listOf(normalized)
    val last9 = if (digits.length >= 9) digits.takeLast(9) else digits
    val candidates = linkedSetOf<String>()
    candidates.add(normalized)
    if (normalized.startsWith("+254")) {
        candidates.add("0$last9")
    }
    if (normalized.startsWith("0")) {
        candidates.add("+254$last9")
    }
    if (digits.length == 9) {
        candidates.add("0$digits")
        candidates.add("+254$digits")
    }
    return candidates.toList()
}
